"""
With running this file, Hyper-parameter optimization task will perform. 
As of this moment it just optimizes learning rate and dropout with trialing 10 different values.
"""
