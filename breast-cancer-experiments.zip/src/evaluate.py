"""

    put the entire evaluation pipeline here
    this file uses the config.yaml to create the model, prepare and load data
    and all the other necessary steps to start an evaluation job and report all the necessary metrics
    these metrics are used to create the model-card corresponding to each training-job

"""
