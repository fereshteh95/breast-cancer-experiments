"""
The metrics calculated in Evaluator class are tested hear. 
The test arrays are located in the test folder.
"""
