from .base import ModelBuilderBase
from .patch_resnet_model import PatchModelBuilder
from .whole_image_model import WholeModelBuilder

